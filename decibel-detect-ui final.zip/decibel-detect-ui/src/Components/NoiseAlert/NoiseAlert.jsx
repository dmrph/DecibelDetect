import React from 'react'

export const NoiseAlert = () => {
  return (
    <div className = 'noise'>
        <h1>Noise Alerts Here!</h1>
    </div>
  )
}

export default NoiseAlert