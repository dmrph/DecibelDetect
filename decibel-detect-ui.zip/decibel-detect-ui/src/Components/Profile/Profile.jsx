import React from 'react'

export const Profile = () => {
  return (
    <div className = 'Profile'>
        <h1>Hello User!</h1>
    </div>
  )
}

export default Profile